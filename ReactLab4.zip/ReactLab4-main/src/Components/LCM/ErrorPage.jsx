import React, { Component } from "react";

class ErrorPage extends Component {
  render() {
    return (
      <>
        <h2 className="alert alert-danger">Error, Something went wrong</h2>
      </>
    );
  }
}

export default ErrorPage;
