import React from "react";

export default function Notfound() {
  return (
    <>
      <div className="min-vh-100 d-flex align-items-center justify-content-center">
        <h2 className="alert alert-danger w-75 text-center ">
          404, Page Not Found
        </h2>
      </div>
    </>
  );
}
